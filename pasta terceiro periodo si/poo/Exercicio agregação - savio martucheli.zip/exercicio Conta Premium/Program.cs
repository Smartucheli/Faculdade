﻿using System;

namespace program {
    class program {
        public static void Main(string[] args){
            conta_premium.Conta_Premium();
            
        }
    }
}